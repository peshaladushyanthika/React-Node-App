# Express API templete
To create a new directory
## mkdir express-api-template
To create package.json for this directory
## npm init --yes
To install express
## npm i express
To install nodemon
## npm i nodemon
To ensure Express.js working , have to add this line in package.json
## "start" : "node index.js"
To install PostgreSQL for the database
##  npm i sequelize pg pg-hstore
To enter for directory
## cd directory_name




